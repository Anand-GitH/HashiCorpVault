#!/bin/bash
# Script for getting credentials from Hashicorp vault
stdincount=1   #Number of inputs to be passed thru STDIN as key:value pair and processed in function processStdInput
export PATH="/home/oracle/scripts/hashicorp/scripts:$PATH"

while getopts k: flag
do
  case "${flag}" in
    k) nckey=${OPTARG};;
    a) auth=${OPTARG};;
  esac
done

ckey=`echo $nckey | sed "s|;.*||"`
dstore=`echo $nckey | sed "s|${ckey};||"`

processStdInput() {
input_param=$1
key=`echo $input_param | sed "s|:.*||"`
value=`echo $input_param | sed "s|${key}:||"`

if [ -f "$destdir" ]
then
    echo "$input_param" > "$destdir"
fi

#Parse the values from STDIN Parameters
if [ "$key" = "AuthToken" ]
then
 auth=$value
fi
}

while [ "$stdincount" -gt 0 ]
do
  read -s -p "Auth token (in format AuthToken:xxxx):" invalue
  processStdInput $invalue
  stdincount=`expr $stdincount - 1`
done

NEWPASS=$(curl -sS --fail -H "X-Vault-Token: ${auth}" http://localhost:8200/v1/${dstore}/${ckey} | jq -r '.data.password')

retval=$?
if [[ $retval -ne 0 ]]; then
  echo "Error getting password from  Vault"
else
  echo "pass:${NEWPASS}"
fi

