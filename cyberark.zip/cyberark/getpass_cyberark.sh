#!/bin/sh
#Script to get the password from CyberArk using the CyberArk Credential ID, Cert file and CyberArk User
cyberarkurl="services-uscentral.skytap.com:11613"
timeout=300     #Mention timeout for curl calls
stdincount=2   #Number of inputs to be passed thru STDIN as key:value pair and processed in function processStdInput
respfile=$(mktemp ./CyberArkOutput.XXXXXXXX)   #to store curl output for temp processing

processStdInput() {
input_param=$1
key=`echo $input_param | sed "s|:.*||"`
value=`echo $input_param | sed "s|${key}:||"`

processJson() {
input_param=$(cat $1)
errmsg=$(echo $input_param | jq '.ErrorCode+ ":" + .ErrorMessage')
echo $errmsg 1>&2
}

#Parse the values from STDIN Parameters
if [ "$key" = "auth" ]
then
  auth=$value
  cuser=`echo $auth | sed "s|;.*||"`
  cpwd=`echo $auth | sed "s|${cuser};||"`
fi

if [ "$key" = "cert" ]
then
  cert=$value
  certloc=`echo $cert | sed "s|;.*||"`
  certkey=`echo $cert | sed "s|${certloc};||"`
fi
}

while getopts k: flag
do
    case "${flag}" in
        k) credid=${OPTARG};;
    esac
done

while [ "$stdincount" -gt 0 ]
do
  read -s -p "Enter the input:" invalue
  processStdInput $invalue
  stdincount=`expr $stdincount - 1`
done

#Getting token
htcode=$(curl -s -k --max-time $timeout -o $respfile -w '%{http_code}' --cert-type P12 --cert $certloc:$certkey --location https://$cyberarkurl/PasswordVault/API/Auth/CyberArk/Logon --header "Content-Type: application/json" --data "{\"username\": \"$cuser\",\"password\": \"$cpwd\"}")

if [[ "$htcode" == 000 ]]; then
  echo "Curl API call timed out" 1>&2
  rm -f $respfile
  exit 1
elif [[ "$htcode" =~ ^4 ]]; then
  processJson $respfile
  rm -f $respfile
  exit 1
elif [[ "$htcode" =~ ^2 ]]; then
  token_id=$(cat $respfile | tr -d '"')
fi

#Get the latest password from the CyberArk for given credential ID
hpcode=$(curl -s -k --max-time $timeout -o $respfile -w '%{http_code}' --cert-type P12 --cert $certloc:$certkey --location "https://$cyberarkurl/PasswordVault/API/Accounts/$credid//Password/Retrieve/" --header "Authorization: ${token_id}" --header "Content-Type: application/json" --data "{reason:\"Testing\"}")

if [[ "$hpcode" == 000 ]]; then
  echo "Curl API call timed out" 1>&2
  rm -f $respfile
  exit 1
elif [[ "$hpcode" =~ ^4 ]]; then
  processJson $respfile
  rm -f $respfile
  exit 1
elif [[ "$hpcode" =~ ^2 ]]; then
  npwd=$(cat $respfile | tr -d '"')
  rm -f $respfile
fi

echo "\npass:${npwd}"
